"""
Trade Recorder Observer

Records all completed trade details during backtesting for later analysis
and reporting.

Note: This observer works by monkey-patching the strategy's notify_trade method
to intercept trade notifications and record them.
"""
import backtrader as bt
from typing import Dict, List
import logging

logger = logging.getLogger(__name__)


class TradeRecorder(bt.Observer):
    """
    Backtrader Observer that records all completed trade details

    This observer tracks completed trades (position closed) and stores
    comprehensive trade information including:
    - Entry/exit times
    - Side (BUY/SELL)
    - Entry/exit prices
    - Position size
    - Commission costs
    - Profit and loss

    The recorded trades can be accessed via the `trades` attribute after
    backtesting completes.

    Attributes:
        trades (List[Dict]): List of recorded trade dictionaries

    Example:
        >>> cerebro = bt.Cerebro()
        >>> cerebro.addstrategy(MyStrategy)
        >>> cerebro.addobserver(TradeRecorder)
        >>> results = cerebro.run()
        >>> strategy = results[0]
        >>> observer = strategy.observers[0]  # TradeRecorder
        >>> trades = observer.trades
        >>> for trade in trades:
        ...     # Access trade data: trade['side'], trade['pnl']
    """

    # Observer needs at least one line even if we don't use it
    lines = ('dummy',)

    # Observer parameters (none needed for this observer)
    params = ()

    plotinfo = dict(plot=False)  # Don't plot this observer

    def __init__(self):
        """Initialize the trade recorder"""
        self.trades: List[Dict] = []
        self._recorded_trade_ids = set()  # Track recorded trades by ref
        self._original_notify_trade = None

        # Hook into the strategy's notify_trade method
        strategy = self._owner
        if hasattr(strategy, 'notify_trade'):
            self._original_notify_trade = strategy.notify_trade

            # Create a wrapper that calls both methods
            def notify_trade_wrapper(trade):
                # First, record the trade
                self._record_trade(trade)
                # Then call the original method if it exists
                if self._original_notify_trade:
                    self._original_notify_trade(trade)

            # Replace the strategy's notify_trade
            strategy.notify_trade = notify_trade_wrapper

    def next(self):
        """
        Called for each bar - set dummy line value

        Trade recording happens in the hooked notify_trade method.
        """
        # Set dummy line to 0 (required by Backtrader)
        self.lines.dummy[0] = 0

    def _record_trade(self, trade):
        """
        Record a completed trade's details

        Args:
            trade: Backtrader Trade object
        """
        # Only record closed trades
        if not trade.isclosed:
            return

        # Check if we've already recorded this trade (by unique ref)
        if trade.ref in self._recorded_trade_ids:
            return

        # Get the data feed
        data = trade.data

        # Get entry and exit datetimes
        # Backtrader stores datetimes as float, need to convert
        entry_dt = data.num2date(trade.dtopen)
        exit_dt = data.num2date(trade.dtclose)

        # Determine trade side
        # Trade is long if trade.long is True
        side = 'BUY' if trade.long else 'SELL'

        # Default values
        entry_price = float(trade.price)
        exit_price = float(trade.price)  # Default to entry price
        trade_size = 1.0  # Default size

        # Get detailed trade information from history if available
        if trade.historyon and len(trade.history) > 0:
            # History events contain the lifecycle of the trade
            # Event 0: Opening
            # Event -1: Closing
            opening_event = trade.history[0]
            closing_event = trade.history[-1]

            # Entry information from opening event
            if hasattr(opening_event, 'status'):
                if hasattr(opening_event.status, 'price'):
                    entry_price = float(opening_event.status.price)
                if hasattr(opening_event.status, 'size'):
                    trade_size = abs(float(opening_event.status.size))

            # Exit information from closing event
            # IMPORTANT: Use event.price for exit price, not status.price
            # status.price contains the entry price even in closing event
            # event.price contains the actual execution price of the closing order
            if hasattr(closing_event, 'event'):
                if hasattr(closing_event.event, 'price'):
                    exit_price = float(closing_event.event.price)
                elif hasattr(closing_event, 'status') and hasattr(closing_event.status, 'price'):
                    # Fallback to status.price (may be wrong)
                    exit_price = float(closing_event.status.price)
            elif hasattr(closing_event, 'status') and hasattr(closing_event.status, 'price'):
                # Last resort fallback
                exit_price = float(closing_event.status.price)

            logger.debug(
                f"Trade {trade.ref}: Using history - "
                f"entry_price={entry_price}, exit_price={exit_price}, size={trade_size}"
            )
        else:
            # Fallback: calculate exit price and size from available data
            logger.warning(f"Trade {trade.ref}: No history available, using fallback calculations")

            # Calculate exit price from PnL if possible
            # PnL = size * (exit_price - entry_price) for long
            # PnL = size * (entry_price - exit_price) for short
            if trade_size == 1.0 and trade.pnl != 0:
                # Estimate price difference
                # Assuming size=1 (Backtrader default), price_diff = pnl
                price_diff = abs(trade.pnl)

                if side == 'BUY':
                    exit_price = entry_price + price_diff
                else:  # SELL
                    exit_price = entry_price - price_diff

            # Try to calculate size from cost and price
            if hasattr(trade, 'value') and trade.value > 0:
                # value is the position value in currency
                # size = value / price
                trade_size = trade.value / entry_price
                logger.debug(f"Trade {trade.ref}: Calculated size from value: {trade_size}")

        # Additional validation: recalculate PnL to verify consistency
        expected_pnl = 0.0
        if side == 'BUY':
            expected_pnl = trade_size * (exit_price - entry_price)
        else:  # SELL
            expected_pnl = trade_size * (entry_price - exit_price)

        # Log if PnL doesn't match (more than 10% difference)
        if trade.pnl != 0 and abs(expected_pnl - trade.pnl) / abs(trade.pnl) > 0.1:
            logger.warning(
                f"Trade {trade.ref}: PnL mismatch - "
                f"expected={expected_pnl:.2f}, actual={trade.pnl:.2f}, "
                f"size={trade_size}, entry={entry_price}, exit={exit_price}"
            )

        # Create trade record
        trade_record = {
            'entry_time': entry_dt.isoformat(),
            'exit_time': exit_dt.isoformat(),
            'side': side,
            'entry_price': entry_price,
            'exit_price': exit_price,
            'size': trade_size,
            'commission': float(trade.commission),
            'pnl': float(trade.pnl),  # Gross PnL from Backtrader
        }

        logger.info(
            f"Trade {trade.ref}: {side} {trade_size:.4f} @ "
            f"{entry_price:.2f} -> {exit_price:.2f}, PnL=${trade.pnl:.2f}"
        )

        # Add to trades list
        self.trades.append(trade_record)

        # Mark as recorded
        self._recorded_trade_ids.add(trade.ref)
