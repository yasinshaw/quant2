"""FastAPI endpoints for live trading management.

Provides start/stop/status controls, real-time market data, position info,
and trade history for the live trader subprocess.
"""
import asyncio
import logging
import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException

from backend.config import settings
from backend.live.trader import read_state_from_file

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/live", tags=["Live Trading"])

_PROJECT_ROOT = Path(__file__).parent.parent.parent
_PID_FILE = _PROJECT_ROOT / "data" / "live_trader.pid"
_LOG_FILE = _PROJECT_ROOT / "logs" / "live_trader.log"

# Singleton OKX client — reused across requests to avoid TCP/TLS re-handshake
_okx_client = None
_okx_client_lock = asyncio.Lock()


def _is_running() -> bool:
    if not _PID_FILE.exists():
        return False
    try:
        pid = int(_PID_FILE.read_text().strip())
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, ValueError, PermissionError):
        _PID_FILE.unlink(missing_ok=True)
        return False


async def _get_okx_client():
    """Return a cached OKX client, creating one if needed."""
    global _okx_client
    from backend.live.okx_client import OKXClient

    if _okx_client is not None:
        return _okx_client

    async with _okx_client_lock:
        # Double-check after acquiring lock
        if _okx_client is not None:
            return _okx_client

        client = OKXClient(
            api_key=settings.okx_api_key,
            secret_key=settings.okx_secret_key,
            passphrase=settings.okx_passphrase,
            symbol=settings.okx_symbol,
            leverage=settings.okx_leverage,
            margin_mode=settings.okx_margin_mode,
            proxy=settings.https_proxy,
        )
        # Warm up the connection with a lightweight call
        try:
            await client.fetch_ticker()
        except Exception:
            # If warmup fails, still keep the client — it may work next time
            pass
        _okx_client = client
        return _okx_client


async def _reset_okx_client():
    """Close and discard the cached client (e.g. on auth errors)."""
    global _okx_client
    async with _okx_client_lock:
        if _okx_client is not None:
            try:
                await _okx_client.close()
            except Exception:
                pass
            _okx_client = None


# ------------------------------------------------------------------
# Status & control
# ------------------------------------------------------------------

@router.get("/status")
async def get_status():
    """Get comprehensive live trader status including account info."""
    running = _is_running()
    state = read_state_from_file() or {
        "status": "never_started",
        "position": {"direction": "flat", "size": 0},
    }

    # Remove equity_history to reduce response size
    if "equity_history" in state:
        del state["equity_history"]

    # Always try to fetch live data if OKX is configured
    account = None
    ticker = None
    position = None
    trades = []

    if settings.okx_api_key and settings.okx_api_key != "your_api_key_here":
        try:
            client = await _get_okx_client()
            account, ticker, position, trades = await asyncio.gather(
                client.fetch_balance(),
                client.fetch_ticker(),
                client.fetch_position(),
                client.fetch_my_trades(limit=20),  # Reduce from 50 to 20
            )
        except Exception as e:
            logger.warning(f"Failed to fetch live data: {e}")
            await _reset_okx_client()

    return {
        "running": running,
        "pid": int(_PID_FILE.read_text().strip()) if running and _PID_FILE.exists() else None,
        "state": state,
        "account": account,
        "ticker": _format_ticker(ticker) if ticker else None,
        "exchange_position": position,
        "recent_trades": [_format_trade(t) for t in trades],
    }


@router.post("/start")
async def start_trader():
    if _is_running():
        raise HTTPException(status_code=409, detail="Live trader is already running")

    _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

    log_fh = open(_LOG_FILE, "a")
    proc = subprocess.Popen(
        [sys.executable, "-m", "backend.live"],
        stdout=log_fh,
        stderr=log_fh,
        cwd=str(_PROJECT_ROOT),
        start_new_session=True,
    )

    _PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    _PID_FILE.write_text(str(proc.pid))

    logger.info(f"Live trader started with PID {proc.pid}")
    return {
        "status": "started",
        "pid": proc.pid,
        "log_file": str(_LOG_FILE),
    }


@router.post("/stop")
async def stop_trader():
    if not _is_running():
        raise HTTPException(status_code=404, detail="Live trader is not running")

    pid = int(_PID_FILE.read_text().strip())
    try:
        os.kill(pid, signal.SIGTERM)
        logger.info(f"Sent SIGTERM to live trader (PID {pid})")
    except ProcessLookupError:
        pass

    _PID_FILE.unlink(missing_ok=True)
    return {"status": "stopped", "pid": pid}


@router.get("/logs")
async def get_logs(lines: int = 100):
    if not _LOG_FILE.exists():
        return {"logs": "", "lines": 0}
    try:
        result = subprocess.run(
            ["tail", "-n", str(lines), str(_LOG_FILE)],
            capture_output=True, text=True, timeout=5
        )
        return {"logs": result.stdout, "lines": lines}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read logs: {e}")


# ------------------------------------------------------------------
# Trade history from OKX
# ------------------------------------------------------------------

@router.get("/trades")
async def get_trades(limit: int = 50):
    """Fetch trade history directly from OKX."""
    try:
        client = await _get_okx_client()
        trades = await client.fetch_my_trades(limit=limit)
        return [_format_trade(t) for t in trades]
    except Exception as e:
        await _reset_okx_client()
        raise HTTPException(status_code=500, detail=f"Failed to fetch trades: {e}")


@router.get("/klines")
async def get_klines(timeframe: str = "4h", limit: int = 200):
    """Fetch OHLCV candlestick data from OKX."""
    try:
        client = await _get_okx_client()
        ohlcv = await client.fetch_ohlcv(timeframe=timeframe, limit=limit)
        # Convert from [[timestamp, open, high, low, close, volume], ...]
        # to more readable format
        return {
            "timeframe": timeframe,
            "data": [
                {
                    "time": int(candle[0] / 1000),  # Convert ms to seconds
                    "open": float(candle[1]),
                    "high": float(candle[2]),
                    "low": float(candle[3]),
                    "close": float(candle[4]),
                    "volume": float(candle[5]),
                }
                for candle in ohlcv
            ]
        }
    except Exception as e:
        await _reset_okx_client()
        raise HTTPException(status_code=500, detail=f"Failed to fetch klines: {e}")


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _format_ticker(ticker: dict) -> dict:
    """Extract relevant ticker fields."""
    return {
        "symbol": ticker.get("symbol", ""),
        "last": ticker.get("last", 0),
        "bid": ticker.get("bid", 0),
        "ask": ticker.get("ask", 0),
        "high": ticker.get("high", 0),
        "low": ticker.get("low", 0),
        "change": ticker.get("change", 0),
        "percentage": ticker.get("percentage", 0),
        "timestamp": ticker.get("timestamp", 0),
    }


def _format_trade(trade: dict) -> dict:
    """Extract and format trade fields for frontend."""
    raw = trade.get("info", {})
    side = trade.get("side", "")
    pos_side = raw.get("posSide", "")

    if side == "buy" and pos_side == "long":
        action = "open_long"
    elif side == "sell" and pos_side == "long":
        action = "close_long"
    elif side == "sell" and pos_side == "short":
        action = "open_short"
    elif side == "buy" and pos_side == "short":
        action = "close_short"
    else:
        action = side

    return {
        "id": trade.get("id", ""),
        "order_id": trade.get("order", ""),
        "timestamp": trade.get("timestamp", 0),
        "datetime": trade.get("datetime", ""),
        "symbol": trade.get("symbol", ""),
        "side": side,
        "action": action,
        "pos_side": pos_side,
        "price": float(trade.get("price", 0)),
        "amount": float(trade.get("amount", 0)),
        "cost": float(trade.get("cost", 0)),
        "fee": {
            "currency": trade.get("fee", {}).get("currency", ""),
            "cost": float(trade.get("fee", {}).get("cost", 0)),
        },
    }
