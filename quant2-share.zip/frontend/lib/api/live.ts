import api from '../api';

// --- Types ---

export interface LiveState {
  status: string;
  updated_at: string;
  symbol: string;
  timeframe: string;
  last_bar_time: string | null;
  position: {
    direction: 'flat' | 'long' | 'short';
    size: number;
    entry_price: number;
    stop_loss: number;
    scaled_out: boolean;
  };
  peak_equity: number;
  was_squeezed: boolean;
  squeeze_bars: number;
}

export interface AccountInfo {
  free: number;
  used: number;
  total: number;
}

export interface TickerInfo {
  symbol: string;
  last: number;
  bid: number;
  ask: number;
  high: number;
  low: number;
  change: number;
  percentage: number;
  timestamp: number;
}

export interface ExchangePosition {
  direction: 'long' | 'short';
  size: number;
  entry_price: number;
  unrealized_pnl: number;
  notional: number;
}

export interface TradeRecord {
  id: string;
  order_id: string;
  timestamp: number;
  datetime: string;
  symbol: string;
  side: string;
  action: string;
  pos_side: string;
  price: number;
  amount: number;
  cost: number;
  fee: { currency: string; cost: number };
}

export interface LiveStatusResponse {
  running: boolean;
  pid: number | null;
  state: LiveState;
  account: AccountInfo | null;
  ticker: TickerInfo | null;
  exchange_position: ExchangePosition | null;
  recent_trades: TradeRecord[];
}

export interface StartResponse {
  status: string;
  pid: number;
  log_file: string;
}

export interface StopResponse {
  status: string;
  pid: number;
}

export interface Kline {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface KlinesResponse {
  timeframe: string;
  data: Kline[];
}

// --- API ---

export const liveApi = {
  getStatus: async (): Promise<LiveStatusResponse> => {
    console.log('[liveApi] Calling getStatus...');
    try {
      const res = await api.get<LiveStatusResponse>('/api/v1/live/status');
      console.log('[liveApi] getStatus response:', res.data);
      return res.data;
    } catch (error) {
      console.error('[liveApi] getStatus error:', error);
      throw error;
    }
  },

  start: async (): Promise<StartResponse> => {
    const res = await api.post<StartResponse>('/api/v1/live/start');
    return res.data;
  },

  stop: async (): Promise<StopResponse> => {
    const res = await api.post<StopResponse>('/api/v1/live/stop');
    return res.data;
  },

  getTrades: async (limit = 50): Promise<TradeRecord[]> => {
    const res = await api.get<TradeRecord[]>('/api/v1/live/trades', {
      params: { limit },
    });
    return res.data;
  },

  getLogs: async (lines = 100): Promise<{ logs: string; lines: number }> => {
    const res = await api.get('/api/v1/live/logs', { params: { lines } });
    return res.data;
  },

  getKlines: async (timeframe = '4h', limit = 200): Promise<KlinesResponse> => {
    const res = await api.get<KlinesResponse>('/api/v1/live/klines', {
      params: { timeframe, limit },
    });
    return res.data;
  },
};
