/**
 * CSV Parser for optimization results
 */

export interface CSVRow {
  rank: number;
  parameters: Record<string, string | number>;
  pnl?: number;
  pnl_pct?: number;
  total_trades?: number;
  win_rate?: number;
  sharpe_ratio?: number;
  max_drawdown?: number;
  composite_score?: number;
  is_best?: string;
  score?: number;
  total_return?: number;
  profit_factor?: number;
}

export interface ParsedCSV {
  headers: string[];
  rows: CSVRow[];
  parameterNames: string[];
}

/**
 * Parse CSV content exported from optimization results
 */
export function parseOptimizationCSV(csvContent: string): ParsedCSV {
  const lines = csvContent.trim().split('\n');

  if (lines.length < 2) {
    throw new Error('CSV file is empty or invalid');
  }

  // Parse header
  const headers = parseCSVLine(lines[0]);

  // Identify which columns are parameters (before performance metrics)
  const paramNames: string[] = [];

  // Performance metric columns that mark the end of parameters
  const metricColumns = ['PnL ($)', 'PnL', 'PnL (%)', 'PnL %', 'Total Trades',
                         'Win Rate (%)', 'Win Rate', 'Sharpe Ratio', 'Sharpe',
                         'Max Drawdown (%)', 'Max DD', 'Composite Score', 'Is Best',
                         'Score', 'Total Return (%)', 'Total Return', 'Profit Factor'];

  for (const header of headers) {
    // Skip Rank column
    if (header === 'Rank') {
      continue;
    }

    // Stop when we hit performance metrics
    if (metricColumns.includes(header)) {
      break;
    }

    // Everything else is a parameter
    paramNames.push(header);
  }

  // Parse data rows
  const rows: CSVRow[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);

    if (values.length !== headers.length) {
      continue;
    }

    const row: CSVRow = {
      rank: parseInt(values[0]) || i,
      parameters: {},
    };

    // Map values to headers
    headers.forEach((header, index) => {
      const value = values[index]?.trim();

      if (header === 'Rank') {
        row.rank = parseInt(value) || i;
      } else if (paramNames.includes(header)) {
        // This is a parameter
        row.parameters[header] = parseValue(value);
      } else if (header === 'PnL ($)' || header === 'PnL') {
        row.pnl = parseFloat(value?.replace('$', '').replace(',', '')) || 0;
      } else if (header === 'PnL (%)' || header === 'PnL %') {
        row.pnl_pct = parseFloat(value?.replace('%', '').replace(',', '')) || 0;
      } else if (header === 'Total Trades') {
        row.total_trades = parseInt(value) || 0;
      } else if (header === 'Win Rate (%)' || header === 'Win Rate') {
        row.win_rate = parseFloat(value?.replace('%', '').replace(',', '')) || 0;
      } else if (header === 'Sharpe Ratio' || header === 'Sharpe') {
        row.sharpe_ratio = parseFloat(value) || 0;
      } else if (header === 'Max Drawdown (%)' || header === 'Max DD') {
        row.max_drawdown = parseFloat(value?.replace('%', '').replace(',', '')) || 0;
      } else if (header === 'Composite Score' || header === 'Composite') {
        row.composite_score = parseFloat(value) || 0;
      } else if (header === 'Is Best') {
        row.is_best = value;
      } else if (header === 'Score') {
        row.score = parseFloat(value) || 0;
      } else if (header === 'Total Return (%)' || header === 'Total Return') {
        row.total_return = parseFloat(value?.replace('%', '').replace(',', '')) || 0;
      } else if (header === 'Profit Factor') {
        row.profit_factor = parseFloat(value) || 0;
      }
    });

    rows.push(row);
  }

  return {
    headers,
    rows,
    parameterNames: paramNames,
  };
}

/**
 * Parse a single CSV line, handling quoted values
 */
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        // Escaped quote
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }

  result.push(current);
  return result;
}

/**
 * Parse a value from CSV string to appropriate type
 */
function parseValue(value: string): string | number {
  value = value?.trim() || '';

  // Try parsing as number
  if (/^-?\d+\.?\d*$/.test(value)) {
    const num = parseFloat(value);
    if (!isNaN(num)) {
      return num;
    }
  }

  return value;
}

/**
 * Get the best row from parsed CSV (rank 1 or is_best === 'Yes')
 */
export function getBestRow(csv: ParsedCSV): CSVRow | null {
  // First try to find row with is_best === 'Yes'
  const bestRow = csv.rows.find(row => row.is_best === 'Yes');
  if (bestRow) {
    return bestRow;
  }

  // Otherwise return first row (rank 1)
  return csv.rows[0] || null;
}
