'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { dataApi, DownloadRequest, DownloadResponse } from '@/lib/api/data';
import DownloadForm from '@/components/DownloadForm';
import DownloadedDataSidebar from '@/components/DownloadedDataSidebar';
import Modal from '@/components/Modal';
import { toast } from '@/lib/toast';

const INTERVALS = [
  { value: '1m', label: '1 Minute' },
  { value: '5m', label: '5 Minutes' },
  { value: '15m', label: '15 Minutes' },
  { value: '1h', label: '1 Hour' },
  { value: '4h', label: '4 Hours' },
  { value: '1d', label: '1 Day' },
  { value: '1w', label: '1 Week' },
];

// Common trading symbols as fallback
const DEFAULT_SYMBOLS = [
  'BTCUSDT',
  'ETHUSDT',
  'SOLUSDT',
  'XRPUSDT',
  'DOGEUSDT',
  'PEPEUSDT',
  'ORDIUSDT',
  'ENJUSDT',
  'BIOUSDT',
  'RAVEUSDT',
  'BASEDUSDT',
  'BNBUSDT',
  'ADAUSDT',
  'DOTUSDT',
  'UNIUSDT',
  'MATICUSDT',
];

export default function DataPage() {
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');
  const [selectedInterval, setSelectedInterval] = useState('1h');
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | undefined>(undefined);
  const [downloadResult, setDownloadResult] = useState<DownloadResponse | null>(null);
  const queryClient = useQueryClient();

  const handleSymbolSelect = (symbol: string, interval: string, datasetId?: number) => {
    setSelectedSymbol(symbol);
    setSelectedInterval(interval);
    setSelectedDatasetId(datasetId);
    setDownloadResult(null);
    // 滚动到顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const { data: symbols } = useQuery({
    queryKey: ['symbols'],
    queryFn: dataApi.getSymbols,
    staleTime: 300000, // 5 minutes
  });

  // Combine API symbols with default symbols, remove duplicates
  const availableSymbols = Array.from(new Set([
    ...(symbols || []),
    ...DEFAULT_SYMBOLS
  ])).sort();

  const downloadMutation = useMutation({
    mutationFn: (request: DownloadRequest) => dataApi.download(request),
    onSuccess: (data) => {
      setDownloadResult(data);
      // 使缓存失效，刷新侧边栏
      queryClient.invalidateQueries({
        queryKey: ['datasets'],
      });
      queryClient.invalidateQueries({
        queryKey: ['dataStatus', data.symbol, data.interval],
      });
    },
    onError: (error: any) => {
      const errorMessage = error.response?.data?.detail || error.message || 'Download failed';
      toast.error(errorMessage);
      setDownloadResult({
        symbol: selectedSymbol,
        interval: selectedInterval,
        count: 0,
        status: 'error',
        message: errorMessage,
      });
    },
  });

  const handleDownload = (startTime: string, endTime: string, datasetName?: string) => {
    setDownloadResult(null);
    downloadMutation.mutate({
      symbol: selectedSymbol,
      interval: selectedInterval,
      start_time: startTime,
      end_time: endTime,
      dataset_name: datasetName,
    });
  };


  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* 左侧侧边栏 */}
        <div className="w-[300px] flex-shrink-0">
          <DownloadedDataSidebar
            onSymbolSelect={handleSymbolSelect}
            selectedDatasetId={selectedDatasetId}
          />
        </div>

        {/* 右侧主内容 */}
        <div className="flex-1 min-w-0 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Data Management</h1>
              <p className="text-gray-600">
                Download and manage historical market data for backtesting
              </p>
            </div>

        {/* Symbol and Interval Selection */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Select Market</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Symbol
              </label>
              <input
                list="symbol-list"
                value={selectedSymbol}
                onChange={(e) => setSelectedSymbol(e.target.value.toUpperCase())}
                placeholder="选择或输入交易对..."
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <datalist id="symbol-list">
                {availableSymbols.map((s) => (
                  <option key={s} value={s} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Interval
              </label>
              <select
                value={selectedInterval}
                onChange={(e) => setSelectedInterval(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {INTERVALS.map((interval) => (
                  <option key={interval.value} value={interval.value}>
                    {interval.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Download Form */}
        <DownloadForm
          onDownload={handleDownload}
          isLoading={downloadMutation.isPending}
          symbol={selectedSymbol}
          interval={selectedInterval}
        />

        {/* Download Result Modal */}
        <Modal
          isOpen={!!downloadResult}
          onClose={() => setDownloadResult(null)}
          title={
            downloadResult?.status === 'downloaded'
              ? '下载成功'
              : downloadResult?.status === 'already_exists'
              ? '数据已存在'
              : '下载失败'
          }
          variant={
            downloadResult?.status === 'downloaded'
              ? 'success'
              : downloadResult?.status === 'already_exists'
              ? 'info'
              : 'error'
          }
        >
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">交易对</p>
                <p className="font-semibold text-gray-900">{downloadResult?.symbol}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">周期</p>
                <p className="font-semibold text-gray-900">{downloadResult?.interval}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm text-gray-500">K线数量</p>
                <p className="font-semibold text-gray-900">
                  {downloadResult?.count.toLocaleString()}
                </p>
              </div>
            </div>
            {downloadResult?.message && (
              <div className="pt-3 border-t border-gray-200">
                <p className="text-sm text-gray-700">{downloadResult.message}</p>
              </div>
            )}
          </div>
        </Modal>
          </div>
        </div>
      </div>
    </div>
  );
}
