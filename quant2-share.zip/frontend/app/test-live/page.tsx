'use client';

import { useEffect, useState } from 'react';
import api from '@/lib/api';

export default function TestLivePage() {
  const [status, setStatus] = useState<string>('Initializing...');
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string>('');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    console.log('[TestLivePage] Component mounted');
    setMounted(true);

    console.log('[TestLivePage] Starting axios call...');
    setStatus('Fetching with axios...');

    api.get('/api/v1/live/status')
      .then(res => {
        console.log('[TestLivePage] Response:', res.data);
        setStatus('Success');
        setData(res.data);
      })
      .catch(err => {
        console.error('[TestLivePage] Error:', err);
        setError(err.message);
        setStatus('Error');
      });
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">Test Live API (axios)</h1>
        <div className="space-y-2">
          <p className="text-lg">Mounted: {mounted ? 'Yes' : 'No'}</p>
          <p className="text-lg">Static content test: This should always be visible</p>
          <p className="text-lg">Status: <span className="font-bold">{status}</span></p>
          {error && <p className="text-red-500">Error: {error}</p>}
        </div>
        {data && (
          <pre className="mt-4 p-4 bg-slate-800 text-green-400 rounded overflow-auto max-h-96">
            {JSON.stringify(data, null, 2)}
          </pre>
        )}
      </div>
    </div>
  );
}
