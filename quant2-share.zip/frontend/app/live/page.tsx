'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { liveApi, TradeRecord, AccountInfo, TickerInfo, ExchangePosition, LiveState } from '@/lib/api/live';
import {
  Activity, Play, Square, TrendingUp, TrendingDown,
  DollarSign, AlertTriangle, RefreshCw, ArrowUpRight,
  ArrowDownRight, Minus,
} from 'lucide-react';
import { useState } from 'react';
import { KlineChart } from '@/components/live/KlineChart';

export default function LivePage() {
  const queryClient = useQueryClient();
  const [logsExpanded, setLogsExpanded] = useState(false);

  // Fetch status every 10 seconds
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['live-status'],
    queryFn: async () => {
      const result = await liveApi.getStatus();
      return result;
    },
    refetchInterval: 10_000,
    retry: 1,
  });

  // Fetch logs
  const { data: logs } = useQuery({
    queryKey: ['live-logs'],
    queryFn: () => liveApi.getLogs(50),
    refetchInterval: 15_000,
    enabled: data?.running,
  });

  const startMutation = useMutation({
    mutationFn: liveApi.start,
    onSuccess: () => {
      setTimeout(() => queryClient.invalidateQueries({ queryKey: ['live-status'] }), 2000);
    },
  });

  const stopMutation = useMutation({
    mutationFn: liveApi.stop,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['live-status'] });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900 p-8">
        <div className="max-w-7xl mx-auto flex flex-col items-center justify-center h-64 gap-4">
          <RefreshCw className="h-8 w-8 animate-spin text-primary-600" />
          <p className="text-slate-600 dark:text-slate-400">Loading live trading data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    console.error('Live page error:', error);
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-slate-900 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-6">
            <AlertTriangle className="h-6 w-6 text-red-600 mb-2" />
            <p className="text-red-800 dark:text-red-200">Failed to load status: {String(error)}</p>
            <button
              onClick={() => refetch()}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  const running = data?.running ?? false;
  const state = data?.state;
  const account = data?.account;
  const ticker = data?.ticker;
  const exchangePosition = data?.exchange_position;
  const rawTrades = data?.recent_trades ?? [];
  const tradePnlMap = computeTradePnls(rawTrades);
  const summary = computeTradeSummary(rawTrades, tradePnlMap);
  const trades = [...rawTrades].reverse();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Activity className="h-8 w-8 text-primary-600" />
            <h1 className="text-3xl font-heading font-bold text-slate-900 dark:text-slate-100">
              Live Trading
            </h1>
            <StatusBadge running={running} />
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => refetch()}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <RefreshCw className="h-4 w-4 text-slate-600 dark:text-slate-400" />
            </button>
            {!running ? (
              <button
                onClick={() => startMutation.mutate()}
                disabled={startMutation.isPending}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Play className="h-4 w-4" />
                {startMutation.isPending ? 'Starting...' : 'Start Trading'}
              </button>
            ) : (
              <button
                onClick={() => stopMutation.mutate()}
                disabled={stopMutation.isPending}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Square className="h-4 w-4" />
                {stopMutation.isPending ? 'Stopping...' : 'Stop Trading'}
              </button>
            )}
          </div>
        </div>

        {/* Top row: Ticker + Account */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Ticker card */}
          <TickerCard ticker={ticker} symbol={state?.symbol ?? ''} />

          {/* Account card */}
          <AccountCard account={account} />

          {/* Position card */}
          <PositionCard
            exchangePos={exchangePosition}
            strategyPos={state}
            ticker={ticker}
          />
        </div>

        {/* Kline Chart */}
        <div className="mb-6">
          <KlineChart symbol={state?.symbol ?? 'ETH/USDT:USDT'} timeframe={state?.timeframe ?? '4h'} height={450} />
        </div>

        {/* Strategy state */}
        {state && (
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-lg font-heading font-semibold text-slate-900 dark:text-slate-100 mb-4">
              Strategy State
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <StatItem label="Symbol" value={state.symbol} />
              <StatItem label="Timeframe" value={state.timeframe} />
              <StatItem label="Stop Loss" value={state.position.stop_loss > 0 ? `$${state.position.stop_loss.toFixed(2)}` : '-'} />
              <StatItem label="Peak Equity" value={state.peak_equity > 0 ? `$${state.peak_equity.toFixed(2)}` : '-'} />
              <StatItem label="Last Bar" value={state.last_bar_time ? formatTime(state.last_bar_time) : '-'} />
            </div>
          </div>
        )}

        {/* Trade history */}
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-heading font-semibold text-slate-900 dark:text-slate-100">
              Recent Trades
            </h2>
            {summary && (
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 dark:text-slate-400">Total PnL:</span>
                  <span className={`font-bold ${summary.totalPnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {summary.totalPnl >= 0 ? '+' : ''}{summary.totalPnl.toFixed(2)} USDT
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 dark:text-slate-400">Total Fees:</span>
                  <span className="font-medium text-slate-700 dark:text-slate-300">
                    {summary.totalFees.toFixed(2)} USDT
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 dark:text-slate-400">Win Rate:</span>
                  <span className={`font-medium ${summary.winRate >= 0.5 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {(summary.winRate * 100).toFixed(0)}%
                  </span>
                </div>
              </div>
            )}
          </div>
          {trades.length === 0 ? (
            <p className="text-slate-500 dark:text-slate-400 text-center py-8">
              No trades yet
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700">
                    <th className="text-left py-2 px-3 text-slate-500 dark:text-slate-400 font-medium">Time</th>
                    <th className="text-left py-2 px-3 text-slate-500 dark:text-slate-400 font-medium">Action</th>
                    <th className="text-right py-2 px-3 text-slate-500 dark:text-slate-400 font-medium">Price</th>
                    <th className="text-right py-2 px-3 text-slate-500 dark:text-slate-400 font-medium">Amount</th>
                    <th className="text-right py-2 px-3 text-slate-500 dark:text-slate-400 font-medium">Fee</th>
                    <th className="text-right py-2 px-3 text-slate-500 dark:text-slate-400 font-medium">PnL</th>
                  </tr>
                </thead>
                <tbody>
                  {trades.map((trade) => (
                    <TradeRow key={trade.id} trade={trade} pnl={tradePnlMap.get(trade.id)} />
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Logs (collapsible) */}
        {running && (
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
            <button
              onClick={() => setLogsExpanded(!logsExpanded)}
              className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-heading font-semibold cursor-pointer"
            >
              {logsExpanded ? '▼' : '▶'} Logs
            </button>
            {logsExpanded && logs?.logs && (
              <pre className="mt-4 p-4 bg-slate-900 text-green-400 rounded-lg text-xs overflow-x-auto max-h-96 overflow-y-auto font-mono">
                {logs.logs}
              </pre>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// --- Sub-components ---

function StatusBadge({ running }: { running: boolean }) {
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium ${
      running
        ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
        : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
    }`}>
      <span className={`h-2 w-2 rounded-full ${running ? 'bg-green-500 animate-pulse' : 'bg-slate-400'}`} />
      {running ? 'Running' : 'Stopped'}
    </span>
  );
}

function TickerCard({ ticker, symbol }: { ticker?: TickerInfo | null; symbol: string }) {
  if (!ticker) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
        <h2 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">{symbol}</h2>
        <p className="text-slate-400 text-sm">No ticker data</p>
      </div>
    );
  }

  const pct = ticker.percentage ?? 0;
  const isUp = pct >= 0;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-medium text-slate-500 dark:text-slate-400">{ticker.symbol || symbol}</h2>
        <span className={`text-xs px-2 py-0.5 rounded ${
          isUp ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
        }`}>
          {isUp ? '+' : ''}{pct.toFixed(2)}%
        </span>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-3xl font-bold text-slate-900 dark:text-slate-100">
          ${ticker.last.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
        {isUp ? (
          <TrendingUp className="h-5 w-5 text-green-600" />
        ) : (
          <TrendingDown className="h-5 w-5 text-red-600" />
        )}
      </div>
      <div className="grid grid-cols-2 gap-2 mt-4 text-xs text-slate-500 dark:text-slate-400">
        <div>High: <span className="text-slate-700 dark:text-slate-300">${ticker.high?.toFixed(2)}</span></div>
        <div>Low: <span className="text-slate-700 dark:text-slate-300">${ticker.low?.toFixed(2)}</span></div>
        <div>Bid: <span className="text-slate-700 dark:text-slate-300">${ticker.bid?.toFixed(2)}</span></div>
        <div>Ask: <span className="text-slate-700 dark:text-slate-300">${ticker.ask?.toFixed(2)}</span></div>
      </div>
    </div>
  );
}

function AccountCard({ account }: { account?: AccountInfo | null }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
      <div className="flex items-center gap-2 mb-4">
        <DollarSign className="h-5 w-5 text-primary-600" />
        <h2 className="text-sm font-medium text-slate-500 dark:text-slate-400">Account (USDT)</h2>
      </div>
      {!account ? (
        <p className="text-slate-400 text-sm">No account data</p>
      ) : (
        <>
          <div className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">
            {account.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">Available</span>
              <span className="text-green-600 dark:text-green-400 font-medium">
                {account.free.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">In Use</span>
              <span className="text-amber-600 dark:text-amber-400 font-medium">
                {account.used.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function PositionCard({
  exchangePos,
  strategyPos,
  ticker,
}: {
  exchangePos?: ExchangePosition | null;
  strategyPos?: LiveState | null;
  ticker?: TickerInfo | null;
}) {
  const sp = strategyPos?.position;
  const dir = exchangePos?.direction ?? sp?.direction ?? 'flat';
  const isLong = dir === 'long';
  const isShort = dir === 'short';

  const size = exchangePos?.size ?? sp?.size ?? 0;
  const entryPrice = exchangePos?.entry_price ?? sp?.entry_price ?? 0;
  const unrealizedPnl = exchangePos?.unrealized_pnl ?? 0;
  const currentPrice = ticker?.last ?? 0;

  // Calculate PnL percentage
  const pnlPct = entryPrice > 0 && currentPrice > 0
    ? ((currentPrice - entryPrice) / entryPrice * 100) * (isLong ? 1 : isShort ? -1 : 0)
    : 0;

  return (
    <div className={`rounded-lg shadow-md p-6 ${
      isLong ? 'bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-800'
        : isShort ? 'bg-red-50 dark:bg-red-900/10 border border-red-200 dark:border-red-800'
        : 'bg-white dark:bg-slate-800'
    }`}>
      <div className="flex items-center gap-2 mb-4">
        {isLong && <ArrowUpRight className="h-5 w-5 text-green-600" />}
        {isShort && <ArrowDownRight className="h-5 w-5 text-red-600" />}
        {!isLong && !isShort && <Minus className="h-5 w-5 text-slate-400" />}
        <h2 className="text-sm font-medium text-slate-500 dark:text-slate-400">Position</h2>
      </div>

      {dir === 'flat' ? (
        <div className="text-slate-400 text-sm py-4 text-center">No open position</div>
      ) : (
        <>
          <div className="flex items-center gap-2 mb-1">
            <span className={`text-lg font-bold uppercase ${
              isLong ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'
            }`}>
              {dir}
            </span>
            <span className="text-lg font-bold text-slate-900 dark:text-slate-100">
              {size.toFixed(4)}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <span className="text-slate-500 dark:text-slate-400 text-xs">Entry</span>
              <div className="text-slate-700 dark:text-slate-300 font-medium">${entryPrice.toFixed(2)}</div>
            </div>
            <div>
              <span className="text-slate-500 dark:text-slate-400 text-xs">Current</span>
              <div className="text-slate-700 dark:text-slate-300 font-medium">${currentPrice.toFixed(2)}</div>
            </div>
            <div>
              <span className="text-slate-500 dark:text-slate-400 text-xs">Unrealized PnL</span>
              <div className={`font-medium ${unrealizedPnl >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {unrealizedPnl >= 0 ? '+' : ''}{unrealizedPnl.toFixed(2)} USDT
              </div>
            </div>
            <div>
              <span className="text-slate-500 dark:text-slate-400 text-xs">Return</span>
              <div className={`font-medium ${pnlPct >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(2)}%
              </div>
            </div>
            {sp && sp.stop_loss > 0 && (
              <div className="col-span-2">
                <span className="text-slate-500 dark:text-slate-400 text-xs">Trailing Stop</span>
                <div className="text-amber-600 font-medium">${sp.stop_loss.toFixed(2)}</div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

const ACTION_LABELS: Record<string, { text: string; color: string }> = {
  open_long: { text: '开多', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' },
  close_long: { text: '平多', color: 'bg-green-50 text-green-600 dark:bg-green-900/20 dark:text-green-300 border border-green-200 dark:border-green-800' },
  open_short: { text: '开空', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
  close_short: { text: '平空', color: 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-300 border border-red-200 dark:border-red-800' },
};

function TradeRow({ trade, pnl }: { trade: TradeRecord; pnl?: number }) {
  const time = trade.datetime
    ? new Date(trade.datetime).toLocaleString()
    : trade.timestamp
      ? new Date(trade.timestamp).toLocaleString()
      : '-';

  const action = ACTION_LABELS[trade.action] ?? {
    text: trade.side.toUpperCase(),
    color: 'bg-slate-100 text-slate-700 dark:bg-slate-700/30 dark:text-slate-300',
  };

  const isClose = trade.action.startsWith('close');

  return (
    <tr className="border-b border-slate-100 dark:border-slate-700/50 hover:bg-slate-50 dark:hover:bg-slate-700/30">
      <td className="py-2 px-3 text-slate-600 dark:text-slate-400 whitespace-nowrap">{time}</td>
      <td className="py-2 px-3">
        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium ${action.color}`}>
          {trade.action.startsWith('open') ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {action.text}
        </span>
      </td>
      <td className="py-2 px-3 text-right text-slate-700 dark:text-slate-300 font-mono">
        ${trade.price.toFixed(2)}
      </td>
      <td className="py-2 px-3 text-right text-slate-700 dark:text-slate-300 font-mono">
        {trade.amount.toFixed(4)}
      </td>
      <td className="py-2 px-3 text-right text-slate-500 dark:text-slate-400 text-xs">
        {trade.fee.cost.toFixed(4)} {trade.fee.currency}
      </td>
      <td className="py-2 px-3 text-right">
        {isClose ? (
          pnl !== undefined ? (
            <span className={`font-medium ${pnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {pnl >= 0 ? '+' : ''}{pnl.toFixed(2)} USDT
            </span>
          ) : (
            <span className="text-slate-400 dark:text-slate-500">-</span>
          )
        ) : (
          <span className="text-slate-400 dark:text-slate-500">-</span>
        )}
      </td>
    </tr>
  );
}

function StatItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-slate-50 dark:bg-slate-700/50 rounded-lg p-3">
      <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">{label}</div>
      <div className="text-sm font-medium text-slate-900 dark:text-slate-100">{value}</div>
    </div>
  );
}

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

// --- Trade PnL Calculation ---

/**
 * Matches open trades with close trades and calculates PnL for each round trip.
 *
 * Algorithm:
 * 1. Collect all open and close trades by direction (long/short)
 * 2. Pair them FIFO: match the earliest open with the earliest close
 * 3. Handle partial closes: if close amount < open amount, mark the remainder
 * 4. Calculate PnL for each close trade:
 *    - Long: (close_price - open_price) * amount - fees
 *    - Short: (open_price - close_price) * amount - fees
 */
function computeTradePnls(trades: TradeRecord[]): Map<string, number> {
  const pnls = new Map<string, number>();
  const pendingOpens: Record<string, TradeRecord[]> = { long: [], short: [] };
  const remainingAmounts: Record<string, number[]> = { long: [], short: [] };

  for (const trade of trades) {
    const isLong = trade.action.includes('long');
    const dir = isLong ? 'long' : 'short';
    const isOpen = trade.action.startsWith('open');
    const isClose = trade.action.startsWith('close');

    if (isOpen) {
      pendingOpens[dir].push(trade);
      remainingAmounts[dir].push(trade.amount);
    } else if (isClose) {
      let closeAmount = trade.amount;
      let closeFee = trade.fee.cost;

      // Match with pending opens (FIFO)
      // Only calculate PnL if we have a matching open
      if (pendingOpens[dir].length > 0) {
        let totalPnlForClose = 0;

        while (closeAmount > 0.000001 && pendingOpens[dir].length > 0) {
          const openTrade = pendingOpens[dir][0];
          const openRemaining = remainingAmounts[dir][0];
          const matchAmount = Math.min(closeAmount, openRemaining);

          // Calculate PnL for this match
          const priceDiff = isLong
            ? trade.price - openTrade.price
            : openTrade.price - trade.price;
          const grossPnl = priceDiff * matchAmount;

          // Fees: proportional to the match amount
          const openFee = openTrade.fee.cost * (matchAmount / openTrade.amount);
          const closeFeeForMatch = closeFee * (matchAmount / trade.amount);
          const netPnl = grossPnl - openFee - closeFeeForMatch;

          totalPnlForClose += netPnl;

          // Update remaining
          closeAmount -= matchAmount;
          remainingAmounts[dir][0] -= matchAmount;

          // If open trade fully matched, remove it
          if (remainingAmounts[dir][0] < 0.000001) {
            pendingOpens[dir].shift();
            remainingAmounts[dir].shift();
          }
        }

        // Only store PnL if we successfully matched with an open trade
        if (totalPnlForClose !== 0 || pendingOpens[dir].length === 0) {
          pnls.set(trade.id, totalPnlForClose);
        }
      }
      // If no matching open, skip this close (it's from before recording started)
    }
  }

  return pnls;
}

interface TradeSummary {
  totalPnl: number;
  totalFees: number;
  winRate: number;
  completedTrades: number;
  winningTrades: number;
}

function computeTradeSummary(trades: TradeRecord[], pnlMap: Map<string, number>): TradeSummary | null {
  let totalPnl = 0;
  let totalFees = 0;
  let winningTrades = 0;
  let completedTrades = 0;

  for (const trade of trades) {
    totalFees += trade.fee.cost;
    const pnl = pnlMap.get(trade.id);
    if (pnl !== undefined) {
      totalPnl += pnl;
      completedTrades++;
      if (pnl > 0) winningTrades++;
    }
  }

  if (completedTrades === 0) return null;

  return {
    totalPnl,
    totalFees,
    winRate: winningTrades / completedTrades,
    completedTrades,
    winningTrades,
  };
}
