'use client';

import React from 'react';
import { formatDisplayDate } from '@/lib/utils/dateFormat';

interface Dataset {
  id: number;
  name: string;
  symbol: string;
  interval: string;
  start_time: string;
  end_time: string;
  candle_count: number;
}

interface ConfigurationSectionProps {
  strategyName: string;
  parameters: Record<string, any>;
  dataset?: Dataset | null;
  backtestStartTime?: string;
  backtestEndTime?: string;
}

/**
 * Displays the strategy configuration used for a backtest.
 * Shows the strategy name, dataset information, and all parameters with their values.
 */
export default function ConfigurationSection({
  strategyName,
  parameters,
  dataset,
  backtestStartTime,
  backtestEndTime
}: ConfigurationSectionProps) {
  // Handle edge case: missing strategy name
  const displayName = strategyName || 'N/A';

  // Format parameter values for display
  const formatValue = (value: any): string => {
    if (value === null || value === undefined) {
      return 'N/A';
    }
    if (typeof value === 'object') {
      return JSON.stringify(value);
    }
    return String(value);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900">Configuration</h2>
        <button
          onClick={() => {
            const paramEntries = Object.entries(parameters);
            const headers = paramEntries.map(([key]) => key);
            const values = paramEntries.map(([, value]) =>
              value === null || value === undefined ? 'N/A' : typeof value === 'object' ? JSON.stringify(value) : String(value)
            );
            const csvContent = [headers, values]
              .map((row) => row.map((cell) => `"${cell}"`).join(','))
              .join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `${strategyName || 'strategy'}_params_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-blue-600 bg-blue-50 rounded-md hover:bg-blue-100 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export Params
        </button>
      </div>

      {/* Strategy and Dataset Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        {/* Strategy Name */}
        <div>
          <p className="text-sm text-gray-600 mb-1">Strategy</p>
          <p className="text-lg font-semibold text-blue-600">
            {displayName}
          </p>
        </div>

        {/* Dataset Information */}
        {dataset ? (
          <>
            <div>
              <p className="text-sm text-gray-600 mb-1">Dataset</p>
              <p className="text-base font-medium text-gray-900">
                {dataset.name}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Backtest Period</p>
              <p className="text-base font-medium text-gray-900">
                {backtestStartTime && backtestEndTime
                  ? `${formatDisplayDate(backtestStartTime)} ~ ${formatDisplayDate(backtestEndTime)}`
                  : `${formatDisplayDate(dataset.start_time)} ~ ${formatDisplayDate(dataset.end_time)}`}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Dataset Range</p>
              <p className="text-base font-medium text-gray-500">
                {formatDisplayDate(dataset.start_time)} ~ {formatDisplayDate(dataset.end_time)}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Data Points</p>
              <p className="text-base font-medium text-gray-900">
                {dataset.candle_count.toLocaleString()} candles
              </p>
            </div>
          </>
        ) : (
          <div className="md:col-span-3">
            <p className="text-sm text-gray-500">No dataset information available</p>
          </div>
        )}
      </div>

      {/* Parameters */}
      {parameters && Object.keys(parameters).length > 0 && (
        <div className="border-t border-gray-200 pt-4">
          <p className="text-sm text-gray-600 mb-2">Strategy Parameters</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {Object.entries(parameters).map(([key, value]) => (
              <div key={key} className="bg-gray-50 rounded p-3">
                <p className="text-xs text-gray-500">{key}</p>
                <p className="text-sm font-medium text-gray-900">
                  {formatValue(value)}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
