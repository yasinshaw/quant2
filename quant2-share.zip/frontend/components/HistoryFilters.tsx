'use client';

import { HistoryQueryParams } from '@/lib/api/history';

interface HistoryFiltersProps {
  filters: HistoryQueryParams;
  onFilterChange: (filters: HistoryQueryParams) => void;
  onClear: () => void;
  strategies?: string[];
  symbols?: string[];
}

const STATUS_OPTIONS = [
  { value: '', label: 'All Statuses' },
  { value: 'pending', label: 'Pending' },
  { value: 'running', label: 'Running' },
  { value: 'completed', label: 'Completed' },
  { value: 'failed', label: 'Failed' },
];

export default function HistoryFilters({
  filters,
  onFilterChange,
  onClear,
  strategies = [],
  symbols = [],
}: HistoryFiltersProps) {
  const hasActiveFilters = filters.strategy_name || filters.symbol || filters.status;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-4 border border-slate-200 dark:border-slate-700">
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Strategy Filter */}
        <div className="flex-1">
          <label
            htmlFor="filter-strategy"
            className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2"
          >
            Strategy
          </label>
          <select
            id="filter-strategy"
            value={filters.strategy_name || ''}
            onChange={(e) =>
              onFilterChange({ ...filters, strategy_name: e.target.value || undefined })
            }
            className="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-3 py-2 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          >
            <option value="">All Strategies</option>
            {strategies.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Symbol Filter */}
        <div className="flex-1">
          <label
            htmlFor="filter-symbol"
            className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2"
          >
            Symbol
          </label>
          <select
            id="filter-symbol"
            value={filters.symbol || ''}
            onChange={(e) =>
              onFilterChange({ ...filters, symbol: e.target.value || undefined })
            }
            className="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-3 py-2 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          >
            <option value="">All Symbols</option>
            {symbols.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="flex-1">
          <label
            htmlFor="filter-status"
            className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2"
          >
            Status
          </label>
          <select
            id="filter-status"
            value={filters.status || ''}
            onChange={(e) =>
              onFilterChange({ ...filters, status: e.target.value || undefined })
            }
            className="w-full border border-slate-300 dark:border-slate-600 rounded-lg px-3 py-2 bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
          >
            {STATUS_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        {/* Clear Button */}
        <div className="flex items-end">
          <button
            type="button"
            onClick={onClear}
            disabled={!hasActiveFilters}
            className="w-full sm:w-auto px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            Clear Filters
          </button>
        </div>
      </div>
    </div>
  );
}
