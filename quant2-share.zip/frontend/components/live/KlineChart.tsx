'use client';

import { useEffect, useRef, useCallback } from 'react';
import { createChart, CandlestickSeries, UTCTimestamp, IChartApi, ISeriesApi } from 'lightweight-charts';
import { useQuery } from '@tanstack/react-query';
import { liveApi } from '@/lib/api/live';

interface KlineChartProps {
  symbol?: string;
  timeframe?: string;
  height?: number;
}

export function KlineChart({ symbol = 'ETH/USDT:USDT', timeframe = '4h', height = 400 }: KlineChartProps) {
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);

  // Fetch klines data
  const { data, isLoading, error } = useQuery({
    queryKey: ['live-klines', timeframe],
    queryFn: () => liveApi.getKlines(timeframe, 200),
    refetchInterval: 60_000,
  });

  // Ref callback to initialize chart when container is mounted
  const setContainerRef = useCallback((node: HTMLDivElement | null) => {
    if (node && !chartRef.current) {
      const chart = createChart(node, {
        width: node.clientWidth || 800,
        height: height,
        layout: {
          background: { color: 'transparent' },
          textColor: '#64748b',
        },
        grid: {
          vertLines: { color: 'rgba(148, 163, 184, 0.1)' },
          horzLines: { color: 'rgba(148, 163, 184, 0.1)' },
        },
        crosshair: { mode: 1 },
        rightPriceScale: {
          borderColor: 'rgba(148, 163, 184, 0.2)',
        },
        timeScale: {
          borderColor: 'rgba(148, 163, 184, 0.2)',
          timeVisible: true,
          secondsVisible: false,
        },
      });

      const series = chart.addSeries(CandlestickSeries, {
        upColor: '#22c55e',
        downColor: '#ef4444',
        borderDownColor: '#ef4444',
        borderUpColor: '#22c55e',
        wickDownColor: '#ef4444',
        wickUpColor: '#22c55e',
      });

      chartRef.current = chart;
      seriesRef.current = series;

      const handleResize = () => {
        chart.applyOptions({ width: node.clientWidth });
      };
      window.addEventListener('resize', handleResize);

      (chart as any)._cleanup = () => {
        window.removeEventListener('resize', handleResize);
        chart.remove();
        chartRef.current = null;
        seriesRef.current = null;
      };
    }
  }, [height]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (chartRef.current && (chartRef.current as any)._cleanup) {
        (chartRef.current as any)._cleanup();
      }
    };
  }, []);

  // Update data when it changes
  useEffect(() => {
    const series = seriesRef.current;
    const chart = chartRef.current;
    if (!series || !chart || !data?.data?.length) return;

    const candlestickData = data.data.map((k) => ({
      time: k.time as UTCTimestamp,
      open: k.open,
      high: k.high,
      low: k.low,
      close: k.close,
    }));
    series.setData(candlestickData);
    chart.timeScale().fitContent();
  }, [data]);

  if (isLoading) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-2">{symbol} - {timeframe} Chart</h2>
        <p className="text-slate-500">Loading...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-2">{symbol} - {timeframe} Chart</h2>
        <p className="text-red-500">Error: {String(error)}</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-md p-6">
      <h2 className="text-lg font-semibold mb-2">{symbol} - {timeframe} Chart</h2>
      <div ref={setContainerRef} style={{ height: `${height}px` }} />
    </div>
  );
}
